import auth from "../app/auth/route";

const routes = [auth];

export default routes;
