export interface ICognitoUser {
  id?: number;
  role: string;
  email: string;
  fullName: string;
}
